<?php

class Home extends CI_Controller
{
  public function _construct()
  {
    parent::_construct;
  }
  public function undex()
  {
    $this->load->view('Home/index');
  }
}