<?php

class Employees extends CI_Controller
{
  public function _construct()
  {
    parent::_construct;
  }
  public function undex()
  {
    $this->load->view('Homepage/index');
  }
}