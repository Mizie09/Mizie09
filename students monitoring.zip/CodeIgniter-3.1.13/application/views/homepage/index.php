<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Dashboard</title>
  <link rel="stylesheet" href="/style.css">

</head>

<body>


  <div>
    <nav>
      <li class="logo"><a href="LOGO">LOGO</a></li>
      <ul>
        <li><a id="active" href="<?= site_url('Homepage') ?>">Home</a></li>
        <li><a href="<?= site_url('Dashboard') ?>">Dashboard</a></li>
        <li><a href="<?= site_url('Employees') ?>">Employees</a></li>
        <li><a href="<?= site_url('Profile') ?>">Profile</a></li>
      </ul>
    </nav>
    <div class="container">
      <div class="strands">



        <div class="strand-box">
          <h3>ICT</h3>
          <a href="">

            <img src="assets/images.jpeg">
          </a>
        </div>
        <div class="strand-box">
          <h3>ICT</h3>
          <a href="">

            <img src="assets/images.jpeg">
          </a>
        </div>
        <div class="strand-box">
          <h3>ICT</h3>
          <a href="">

            <img src="assets/images.jpeg">
          </a>
        </div>
        <div class="strand-box">
          <h3>ICT</h3>
          <a href="">

            <img src="assets/images.jpeg">
          </a>
        </div>
        <div class="strand-box">
          <h3>ICT</h3>
          <a href="">

            <img src="assets/images.jpeg">
          </a>
        </div>
        <div class="strand-box">
          <h3>ICT</h3>
          <a href="">

            <img src="assets/images.jpeg">
          </a>
        </div>

      </div>
    </div>



  </div>

  </div>

</body>

</html>